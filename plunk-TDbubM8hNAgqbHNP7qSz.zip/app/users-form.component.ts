import { Component } from '@angular/core';

import { Users }    from './users';
import { UsersService }    from './users.service';

@Component({
  selector: 'users-form',
  templateUrl: './users-form.component.html'
})
export class UsersFormComponent {

  //model = new Users(1, 'Akeel Munshi', 'akeel.munshi@gmail.com', 'akeelm123');
users: Users[] = [];

constructor(
    private userService: UsersService){
        
    }
 onSubmit(form: any): void {  
    console.log('you submitted value:', form);
    this.userService.create(form);
    
  }

  // TODO: Remove this when we're done
  get diagnostic() { //return JSON.stringify(this.model); 
  }

}